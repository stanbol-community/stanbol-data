# Indexing Configuration for the IPTC Thesaurus

## Setup

1. Stanbol Entityhub Indexing Tool for generic RDF: This tool is not included in this distribution. Please check out Stanbol and Build it. After doing that you can find the Tool in "{stanbol}/entityhub/indexing/genericrdf/target". Copy the Jar with ~25MByte to this Directory.

2. The IPTC Thesaurus: The IPTC defines several controlled Vocabularies. All 6 Descriptive NewsCodes Vocabularies are included within this distribution.

 When downloading your own version or additional controlled vocabularies one needs to consider the following things
 
 * Currently the RDF versions use a wrong SKOS namespace. For all dumps one has to replace "http://www.w3.org/TR/skos-reference/skos.html#" with "http://www.w3.org/2004/02/skos/core#". The files included in this distribution have this error already corrected.
 * The labels included in downloaded files correspond to the language of the browser (or more concrete to the parsed "Accept-Language" header). To get the dumps in all available languages one has to include all languages in this header field (e.g. "Accept-Language: en-GB,fr,de,es,it,jp-JP"). The included files where downloaded by using this header specification.
 * Some labels will contain invalid character (most of the time '&'). This will result in Exceptions while loading those file to the Jena TDB triple store before indexing. In such cases such labels need to be corrected. The http://www.w3.org/RDF/Validator/ can be helpful in detecting and correcting such cases. Labels in those fi

3. Decide about the Data to be indexed. All files within the "/indexing/resource/rdfdata" directory will be indexed. Files you do not want to be indexed can be deleted or moved to an other directory.

## Indexing

If you have completed step 1 of the setup, there should be the JAR file with the indexing utility in this directory. To start the indexing process you will need to call

    java -Xmx1024m -jar org.apache.stanbol.entityhub.indexing.genericrdf-*-jar-with-dependencies.jar index

The indexing should be completed in less than a minute.

## Using the Index within the Entityhub

The files you need to install the IPTC thesaurus in the Entityhub are located in

    /indexing/dist

1. copy the "iptc.solrindex.zip" to the "/sling/datafiles" folder within the home directory of your running Apache Stanbol instance.
2. Install the bundle "org.apache.stanbol.data.site.iptc-1.0.0.jar" by
 * Go to the OSGI Webconsole (http://{host}:{port}/system/console/bundles)
 * Click on "Install/update…"
 * Add this Bundle to the Dialog and activate the "Start Bundle" option
 * Reload the page. Now you should see a Bundle with the Name "Apache Stanbol Data: iptc (org.apache.stanbol.data.site.iptc) "and the Satus "Active"
 * The IPTC thesaurus is now available as ReferencedSite at "http://{host}:{port}/entityhub/site/iptc"
3. If you want you can not delete the "iptc.solrindex.zip" in the "/sling/datafiles" folder.